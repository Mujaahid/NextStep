var navProfileImg = $('div.nav-profile img');
// Get the src attribute of the image
var srcAttr = navProfileImg.attr('src');
// Set the src attribute of another img tag
$('.accountProfile, .profilePreview').attr('src', srcAttr);
// Gets Nav image profile

var myString = $('.nav-name').text();
$('.userRealName').text(myString);
// Get nav user name. 




$(document).ready(function(){
    $('.main-searchbar').click(function(){
        $('.main-nav-drop').slideDown(500);
    });
    $('body').click(function (event) {
        if(!$(event.target).closest('.main-searchbar').length && !$(event.target).is('.main-nav-drop')) {
          $(".main-nav-drop").slideUp();
        }     
     });

     $('.open-nav-job').click(function() {
        $('.main-searchbar-wrapper').slideUp(300)
        $('.jobs-searchbar-wrapper').slideDown(300)
     })
     $('.open-nav-channel').click(function() {
        $('.main-searchbar-wrapper').slideUp(300)
        $('.channels-search-wrapper').slideDown(300)
     })
     $('.open-nav-similar').click(function() {
        $('.main-searchbar-wrapper').slideUp(300)
        $('.similar-searchbar-wrapper').slideDown(300)
     })



     $('.open-jobs').click(function() {
        $('.searchbar-wrapper').slideUp(300)
        $('.jobs-searchbar-wrapper').slideDown(300)
     })
     $('.open-channels').click(function() {
        $('.searchbar-wrapper').slideUp(300)
        $('.channels-search-wrapper').slideDown(300)
     })
     $('.open-content').click(function() {
        $('.searchbar-wrapper').slideUp(300)
        $('.similar-searchbar-wrapper').slideDown(300)
     })
})
// main nav dropdownd

$(document).ready(function(){
    $('.job-searchbar').click(function(){
        $('.job-nav-drop').slideDown(500);
    });
    $('body').click(function (event) {
        if(!$(event.target).closest('.job-searchbar').length && !$(event.target).is('.job-nav-drop')) {
          $(".job-nav-drop").slideUp();
        }     
     });
})
$(document).ready(function(){
    $('.channels-searchbar').click(function(){
        $('.channels-nav-drop').slideDown(500);
    });
    $('body').click(function (event) {
        if(!$(event.target).closest('.channels-searchbar').length && !$(event.target).is('.channels-nav-drop')) {
          $(".channels-nav-drop").slideUp();
        }     
     });
})
$(document).ready(function(){
    $('.similar-nav-searchbar').click(function(){
        $('.similar-nav-drop').slideDown(500);
    });
    $('body').click(function (event) {
        if(!$(event.target).closest('.similar-nav-searchbar').length && !$(event.target).is('.similar-nav-drop')) {
          $(".similar-nav-drop").slideUp();
        }     
     });
})
// Sub nav dropdown functions

// $(".nav_profile_drop").click(function(e){
//     $(".profile_dropdown").slideDown(600);
//     e.stopPropagation();
// });
// $(".profile_dropdown").click(function(e){
//     e.stopPropagation();
// });
// $(document).click(function(){
//     $(".profile_dropdown").slideUp(600);
// });
// // Nav dropdown

$(document).ready(function() {
    $('.settingsModal').hide();
    $('.profileModal').show();

    $('.profileBtn').on('click', function() {
        $('.profileBtn').removeClass('.settingOpt-btn').addClass('.settingOpt-btn-hover')
        $('.settingsModal').hide();
        $('.profileModal').show();
    })
    $('.resumeBtn').on('click', function() {
        $('.settingsModal').hide();
        $('.resumeModal').show();
    })
    $('.socialBtn').on('click', function() {
        $('.settingsModal').hide();
        $('.socialModal').show();
    })
    $('.walletBtn').on('click', function() {
        $('.settingsModal').hide();
        $('.walletModal').show();
    })
    $('.notificationBtn').on('click', function() {
        $('.settingsModal').hide();
        $('.notificationsModal').show();
    })
    $('.messageBtn').on('click', function() {
        $('.settingsModal').hide();
        $('.messagingModal').show();
    })
    $('.passwordBtn').on('click', function() {
        $('.settingsModal').hide();
        $('.passwordModal').show();
    })
    $('.accountBtn').on('click', function() {
        $('.settingsModal').hide();
        $('.accountModal').show();
    })
})
// Buttons that navigate the page


$(document).ready(function() {
    $('.settingOpt').click(function() {
      // Remove the 'active' class from all buttons
      $('.settingOpt').removeClass('active');
      
      // Add the 'active' class to the clicked button
      $(this).addClass('active');
    });
  });
// Button Styles

  
$(document).ready(function() {
    // Click event for the primary button
    $('.btn-primary').click(function() {
      // Create an input element to upload the file
      var file_input = $('<input/>').attr('type', 'file');
      
      // Trigger the click event for the file input
      file_input.trigger('click');
      
      // On file selection, read the file and set the image src for all 'newProfile' img tags
      file_input.change(function() {
        var file = this.files[0];
        var reader = new FileReader();
        reader.readAsDataURL(file);
        
        reader.onload = function(e) {
          var img_src = e.target.result;
          $('img.newProfile').attr('src', img_src);
        }
      });
    });
});
// Upload profile

function dragNdropBanner(event) {
    var bannerFileName = URL.createObjectURL(event.target.files[0]);
    var bannerPreview = document.getElementById("bannerPreview");
    var bannerPreviewImg = document.createElement("img");
    bannerPreviewImg.setAttribute("src", bannerFileName);
    bannerPreview.innerHTML = "";
    bannerPreview.appendChild(bannerPreviewImg);
}
function drag() {
    document.getElementById('read-bannerImageUrl').parentNode.className = 'draging dragBoxBanner';
}
function drop() {
    document.getElementById('read-bannerImageUrl').parentNode.className = 'dragBoxBanner';
}
// Upload banner

let fullTimeCheckBox = $('#fullTime')
$(fullTimeCheckBox).on('click', function(e) {
    if(e.target.checked) {
        $('.hireType-body').show(300)
    } else {
        $('.hireType-body').hide(300)
    }
})

let freelanceCheckBox = $('#freelance')
$(freelanceCheckBox).on('click', function(e) {
    if(e.target.checked) {
        $('.freelancehireType-body').show(300)
    } else {
        $('.freelancehireType-body').hide(300)
    }
})

let contractCheckBox = $('#contract')
$(contractCheckBox).on('click', function(e) {
    if(e.target.checked) {
        $('.contracthireType-body').show(300)
    } else {
        $('.contracthireType-body').hide(300)
    }
})
// Checkbox button functions. 

$('.skillInput').keyup(function(event) {
    let addSkill = $('.skillInput').val();
    if(event.which === 13 && addSkill !== '') {
        $('.skill-body').append(`
            <div class="skill-item">
                <span class="close-skill">
                    <i class="fas fa-times"></i>
                </span>
                <p>${addSkill}</p>
            </div>
        `)
        $('.skillInput').val('');
    }

    $('.close-skill').on('click', function(e) {
        let deleteSkill = $(e.target).parent().parent();
        $(deleteSkill).remove()
    })
})
// Resume function


$('#websiteInput').keyup(function(event) {
    let link = $('#websiteInput').val();
    if(event.which === 13 && link !== '') {
        $('.social-icon-wrapper').append(`
            <div class="socialIcon-item webSocial">
                <span class="deleteIcon deleteWebSocial">
                    <i class="fas fa-times"></i>
                </span>
                <a href="${link}">
                    <div class="socialIcon-content">
                        <i class="fa-solid socialIcon fa-globe"></i>
                        <p>Website</p>
                    </div>
                </a>
            </div>
        `)
        $('#websiteInput').val('');
    }
    $('.deleteWebSocial').on('click', function() {
        $('.webSocial').remove()
    })
})
// Personal Website

$('#behanceInput').keyup(function(event) {
    let link = $('#behanceInput').val();
    if(event.which === 13 && link !== '') {
        $('.social-icon-wrapper').append(`
            <div class="socialIcon-item behanceSocial">
                <span class="deleteIcon deleteBehanceSocial">
                    <i class="fas fa-times"></i>
                </span>
                <a href="${link}">
                    <div class="socialIcon-content">
                        <i class="fa-brands socialIcon fa-behance"></i>
                        <p>Behance</p>
                    </div>
                </a>
            </div>
        `)
        $('#behanceInput').val('');
    }
    $('.deleteBehanceSocial').on('click', function() {
        $('.behanceSocial').remove()
    })
})
// Behance

$('#pinterestInput').keyup(function(event) {
    let link = $('#pinterestInput').val();
    if(event.which === 13 && link !== '') {
        $('.social-icon-wrapper').append(`
            <div class="socialIcon-item pinterestSocial">
                <span class="deleteIcon deletePinterestSocial">
                    <i class="fas fa-times"></i>
                </span>
                <a href="${link}">
                    <div class="socialIcon-content">
                    <i class="fab socialIcon fa-pinterest"></i>
                        <p>Pinterest</p>
                    </div>
                </a>
            </div>
        `)
        $('#pinterestInput').val('');
    }
    $('.deletePinterestSocial').on('click', function() {
        $('.pinterestSocial').remove()
    })
})
// Pinterest

$('#dribbbleInput').keyup(function(event) {
    let link = $('#dribbbleInput').val();
    if(event.which === 13 && link !== '') {
        $('.social-icon-wrapper').append(`
            <div class="socialIcon-item dribbbleSocial">
                <span class="deleteIcon deleteDribbbleSocial">
                    <i class="fas fa-times"></i>
                </span>
                <a href="${link}">
                    <div class="socialIcon-content">
                    <i class="fab socialIcon fa-dribbble"></i>
                        <p>Dribbble</p>
                    </div>
                </a>
            </div>
        `)
        $('#dribbbleInput').val('');
    }
    $('.deleteDribbbleSocial').on('click', function() {
        $('.dribbbleSocial').remove()
    })
})
// Dribbble

$('#instagramInput').keyup(function(event) {
    let link = $('#instagramInput').val();
    if(event.which === 13 && link !== '') {
        $('.social-icon-wrapper').append(`
            <div class="socialIcon-item instagramSocial">
                <span class="deleteIcon deleteInstagramSocial">
                    <i class="fas fa-times"></i>
                </span>
                <a href="${link}">
                    <div class="socialIcon-content">
                    <i class="fab socialIcon fa-instagram"></i>
                        <p>Instagram</p>
                    </div>
                </a>
            </div>
        `)
        $('#instagramInput').val('');
    }
    $('.deleteInstagramSocial').on('click', function() {
        $('.instagramSocial').remove()
    })
})
// Instagram

$('#facebookInput').keyup(function(event) {
    let link = $('#facebookInput').val();
    if(event.which === 13 && link !== '') {
        $('.social-icon-wrapper').append(`
            <div class="socialIcon-item facebookSocial">
                <span class="deleteIcon deleteFacebookSocial">
                    <i class="fas fa-times"></i>
                </span>
                <a href="${link}">
                    <div class="socialIcon-content">
                    <i class="fab socialIcon fa-facebook"></i>
                        <p>Facebook</p>
                    </div>
                </a>
            </div>
        `)
        $('#facebookInput').val('');
    }
    $('.deleteFacebookSocial').on('click', function() {
        $('.facebookSocial').remove()
    })
})
// Facebook

$('#twitterInput').keyup(function(event) {
    let link = $('#twitterInput').val();
    if(event.which === 13 && link !== '') {
        $('.social-icon-wrapper').append(`
        <div class="socialIcon-item twitterSocial">
            <span class="deleteIcon deleteTwitterSocial">
                <i class="fas fa-times"></i>
            </span>
            <a href="${link}">
                <div class="socialIcon-content">
                    <i class="fab socialIcon fa-twitter"></i>
                    <p>Twitter</p>
                </div>
            </a>
        </div>
        `)
        $('#twitterInput').val('');
    }
    $('.deleteTwitterSocial').on('click', function() {
        $('.twitterSocial').remove()
    })
})
// Twitter


let searchUsers = [
    {
        userProfile: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Andrew_Jackson_Daguerrotype-crop.jpg/1024px-Andrew_Jackson_Daguerrotype-crop.jpg',
        userName: 'Andrew Jackson',
        userDescription: '7th U.S. President'
    },
    {
        userProfile: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/57/President_Hoover_portrait.jpg/1024px-President_Hoover_portrait.jpg',
        userName: 'Herbert Hoover',
        userDescription: '31st U.S. President'
    },
    {
        userProfile: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Fillmore.jpg/1200px-Fillmore.jpg',
        userName: 'Millard Fillmore',
        userDescription: '13th U.S. President'
    },
]
// List of users that will be blocked. 
for (let i = 0; i < searchUsers.length; i++) {
    $('.userSearch-dropdown').append(`
        <div class="userSearch-item">
            <div class="userSearch-content">
                <div class="userSearch-profile">
                    <img src="${searchUsers[i].userProfile}" alt="">
                </div>
                <div class="userSearch-name">
                    <h5 class="username" >${searchUsers[i].userName}</h5>
                    <p>${searchUsers[i].userDescription}</p>
                </div>
            </div>
            <div class="block-btn">
                <p>Block</p>
            </div>
        </div>
    `)
    let searchList = $('.userSearch-item > .block-btn');
    
    $(searchList[i]).on('click', () => {
        $('.blocking-wrapper').append(`
            <div class="blockeduser-item">
                <div class="userSearch-content">
                    <div class="userSearch-profile">
                        <img src="${searchUsers[i].userProfile}" alt="">
                    </div>
                    <div class="userSearch-name">
                        <h5>${searchUsers[i].userName}</h5>
                        <p>${searchUsers[i].userDescription}</p>
                    </div>
                </div>
                <span class="unblock-btn">Unblock</span>
            </div>
        `)

        $('.unblock-btn').on('click', function(e) {
            let unblock = $(e.target).parent();
            $(unblock).remove()
            $('#userSearchDropdown').append(`
            <div class="userSearch-item">
                <div class="userSearch-content">
                    <div class="userSearch-profile">
                        <img src="${searchUsers[i].userProfile}" alt="">
                    </div>
                    <div class="userSearch-name">
                        <h5 class="username" >${searchUsers[i].userName}</h5>
                        <p>${searchUsers[i].userDescription}</p>
                    </div>
                </div>
                <div class="block-btn">
                    <p>Block</p>
                </div>
            </div>
        `)
        })
    })
}
// Storing the searched users



// $(document).ready(function() {
//     // Listen for keyup event on filter input field
//     $('#filter').on('keyup', function() {
//       // Get the search query
//       var query = $(this).val().toLowerCase();
  
//       // Show the user search dropdown
//       $('#userSearchDropdown').show();
  
//       // Loop through each user search item
//       $('.userSearch-item').each(function() {
//         // Get the user name text
//         var nameText = $(this).find('.userSearch-name').text().toLowerCase();
  
//         // Check if the user name matches the search query
//         if (nameText.indexOf(query) !== -1) {
//           // If it does, show the user search item
//           $(this).show();
//         } else {
//           // If it doesn't, hide the user search item
//           $(this).hide();
//         }
//       });
//     });
  
//     // Listen for click event on block button
//     $('#userSearchDropdown').on('click', '.block-btn', function() {
//       // Hide the user search dropdown
//       $('#userSearchDropdown').hide();
//     });
  
//     // Listen for click event on document
//     $(document).on('click', function(event) {
//       // Check if the click event target is outside the user search dropdown
//       if (!$(event.target).closest('#userSearchDropdown').length) {
//         // If it is, hide the user search dropdown
//         $('#userSearchDropdown').hide();
//       }
//     });
// });

$(document).ready(function() {
    // Listen for keyup event on filter input field
    $('#filter').on('keyup', function() {
      // Get the search query
      var query = $(this).val().toLowerCase();
  
      // Show the user search dropdown
      $('#userSearchDropdown').show();
  
      // Loop through each user search item
      $('.userSearch-item').each(function() {
        // Get the user name text
        var nameText = $(this).find('.userSearch-name').text().toLowerCase();
  
        // Check if the user name matches the search query
        if (nameText.indexOf(query) !== -1) {
          // If it does, show the user search item
          $(this).show();
        } else {
          // If it doesn't, hide the user search item
          $(this).hide();
        }
      });
    });
  
    // Listen for click event on block button
    $('#userSearchDropdown').on('click', '.block-btn', function(e) {
      // Hide the user search dropdown
      $('#filter').val('');
      $('#userSearchDropdown').hide();

      $('.no-block').hide();
      $('.blockedUser-title').show();
      let userSearchItem = $(e.target).parent().parent()
      $(userSearchItem).remove()
    });
  
    // Listen for click event on document
    $(document).on('click', function(event) {
      // Check if the click event target is outside the user search dropdown
      if (!$(event.target).closest('#userSearchDropdown').length) {
        // If it is, hide the user search dropdown
        $('#userSearchDropdown').hide();
      }
    });
  });
// Searching users to block



$(".account-footer span").on('click', function(e){
    $(".accountModal-background").show();
    e.stopPropagation();
});
$(".deleteAccountWrapper").click(function(e){
    e.stopPropagation();
});
$(document).on('click', function(){
    $(".accountModal-background").hide();
});
$('.cancelDeleteAccount').on('click', function() {
    $(".accountModal-background").hide();
})
// Delete Account